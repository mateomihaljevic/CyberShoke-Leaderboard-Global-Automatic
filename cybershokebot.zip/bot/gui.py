import csv
import os
import sys
import subprocess
from pathlib import Path
from datetime import datetime
import tkinter as tk
from tkinter import ttk, messagebox

DATA_DIR = Path("data")
BOT_FILE = Path("cybershokeleaderboard_bot.py")

COLUMNS = ["Player", "Kills", "HS%", "K/D", "Playtime", "Points"]

NUMERIC_COLS_FLOAT = {"K/D", "HS%"}     # HS% ćemo pretvoriti iz "65%" -> 65.0
NUMERIC_COLS_INT = {"Kills", "Playtime", "Points"}  # već su brojevi u stringu


def newest_csv_file() -> Path | None:
    if not DATA_DIR.exists():
        return None
    files = sorted(DATA_DIR.glob("*.csv"), key=lambda p: p.stat().st_mtime, reverse=True)
    return files[0] if files else None


def read_csv(path: Path) -> list[dict]:
    rows = []
    with path.open("r", encoding="utf-8", newline="") as f:
        reader = csv.DictReader(f, delimiter=";")
        for r in reader:
            rows.append(r)
    return rows


def open_folder(path: Path):
    try:
        if sys.platform.startswith("win"):
            os.startfile(path)  # type: ignore
        elif sys.platform == "darwin":
            os.system(f'open "{path}"')
        else:
            os.system(f'xdg-open "{path}"')
    except Exception as e:
        messagebox.showerror("Greška", f"Ne mogu otvoriti folder: {e}")


def to_float(value: str) -> float | None:
    if value is None:
        return None
    s = str(value).strip()
    if not s:
        return None
    s = s.replace(",", ".")
    if s.endswith("%"):
        s = s[:-1].strip()
    try:
        return float(s)
    except:
        return None


def to_int(value: str) -> int | None:
    if value is None:
        return None
    s = str(value).strip()
    if not s:
        return None
    # već imamo clean brojeve, ali ostavimo safety
    s = "".join(ch for ch in s if ch.isdigit())
    if not s:
        return None
    try:
        return int(s)
    except:
        return None


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("CyberShoke Leaderboard Viewer")
        self.geometry("1180x620")
        self.minsize(1050, 560)

        self.current_file: Path | None = None
        self.all_rows: list[dict] = []
        self.sort_state: dict[str, bool] = {}  # col -> ascending?

        self._build_ui()
        self.load_latest()

    # ---------- UI ----------
    def _build_ui(self):
        # Top row: file info + actions
        top = ttk.Frame(self)
        top.pack(fill="x", padx=10, pady=10)

        self.file_label = ttk.Label(top, text="CSV: (nije učitan)")
        self.file_label.pack(side="left")

        ttk.Button(top, text="Run bot", command=self.run_bot).pack(side="right", padx=(8, 0))
        ttk.Button(top, text="Refresh", command=self.load_latest).pack(side="right", padx=(8, 0))
        ttk.Button(top, text="Open data folder", command=lambda: open_folder(DATA_DIR)).pack(side="right")

        # Filters row
        filters = ttk.LabelFrame(self, text="Filters")
        filters.pack(fill="x", padx=10, pady=(0, 10))

        row1 = ttk.Frame(filters)
        row1.pack(fill="x", padx=10, pady=8)

        ttk.Label(row1, text="Search Player:").pack(side="left")
        self.search_var = tk.StringVar()
        self.search_entry = ttk.Entry(row1, textvariable=self.search_var, width=26)
        self.search_entry.pack(side="left", padx=(6, 14))
        self.search_entry.bind("<KeyRelease>", lambda e: self.apply_filters())

        ttk.Label(row1, text="Min Points:").pack(side="left")
        self.min_points_var = tk.StringVar()
        ttk.Entry(row1, textvariable=self.min_points_var, width=10).pack(side="left", padx=(6, 14))

        ttk.Label(row1, text="Min K/D:").pack(side="left")
        self.min_kd_var = tk.StringVar()
        ttk.Entry(row1, textvariable=self.min_kd_var, width=10).pack(side="left", padx=(6, 14))

        ttk.Label(row1, text="Min HS%:").pack(side="left")
        self.min_hs_var = tk.StringVar()
        ttk.Entry(row1, textvariable=self.min_hs_var, width=10).pack(side="left", padx=(6, 14))

        ttk.Label(row1, text="Min Playtime (h):").pack(side="left")
        self.min_playtime_var = tk.StringVar()
        ttk.Entry(row1, textvariable=self.min_playtime_var, width=10).pack(side="left", padx=(6, 14))

        ttk.Button(row1, text="Apply", command=self.apply_filters).pack(side="right", padx=(8, 0))
        ttk.Button(row1, text="Clear", command=self.clear_filters).pack(side="right")

        # Table
        table_frame = ttk.Frame(self)
        table_frame.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        self.tree = ttk.Treeview(table_frame, columns=COLUMNS, show="headings", height=18)
        self.tree.pack(side="left", fill="both", expand=True)

        scrollbar = ttk.Scrollbar(table_frame, orient="vertical", command=self.tree.yview)
        scrollbar.pack(side="right", fill="y")
        self.tree.configure(yscrollcommand=scrollbar.set)

        widths = {
            "Player": 260,
            "Kills": 90,
            "HS%": 70,
            "K/D": 70,
            "Playtime": 110,
            "Points": 90,
        }

        for col in COLUMNS:
            self.tree.heading(col, text=col, command=lambda c=col: self.sort_by(c))
            self.tree.column(col, width=widths.get(col, 120), anchor="w")

        # Status bar
        bottom = ttk.Frame(self)
        bottom.pack(fill="x", padx=10, pady=(0, 10))

        self.status = ttk.Label(bottom, text="")
        self.status.pack(side="left")

        self.progress = ttk.Label(bottom, text="")
        self.progress.pack(side="right")

    # ---------- Actions ----------
    def clear_filters(self):
        self.search_var.set("")
        self.min_points_var.set("")
        self.min_kd_var.set("")
        self.min_hs_var.set("")
        self.min_playtime_var.set("")
        self.apply_filters()

    def run_bot(self):
        if not BOT_FILE.exists():
            messagebox.showerror("Greška", f"Ne mogu naći {BOT_FILE.name}. Stavi gui.py u isti folder kao bot.py.")
            return

        self.progress.config(text="Running bot...")
        self.update_idletasks()

        try:
            # pokreni bot.py sa istim python interpreterom
            res = subprocess.run(
                [sys.executable, str(BOT_FILE)],
                capture_output=True,
                text=True
            )

            if res.returncode != 0:
                messagebox.showerror("Bot error", f"bot.py nije uspio.\n\nSTDOUT:\n{res.stdout}\n\nSTDERR:\n{res.stderr}")
                self.progress.config(text="")
                return

            # opcionalno: pokaži output u statusu (kratko)
            out = (res.stdout or "").strip()
            if out:
                self.status.config(text=(out.splitlines()[-1][:120]))
        except Exception as e:
            messagebox.showerror("Greška", f"Ne mogu pokrenuti bot.py: {e}")
            self.progress.config(text="")
            return

        self.progress.config(text="")
        self.load_latest()

    def load_latest(self):
        f = newest_csv_file()
        if not f:
            self.file_label.config(text="CSV: (nema datoteka u data/)")
            self.status.config(text="Pokreni bot.py (ili klikni Run bot) da napravi CSV u folderu data/.")
            self.all_rows = []
            self.refresh_table([])
            return

        try:
            rows = read_csv(f)
        except Exception as e:
            messagebox.showerror("Greška", f"Ne mogu pročitati CSV: {e}")
            return

        self.current_file = f
        self.all_rows = rows

        self.file_label.config(text=f"CSV: {f.name}")
        self.status.config(
            text=f"Učitano {len(rows)} redova • Zadnji download liste: {datetime.fromtimestamp(f.stat().st_mtime)}"
        )
        self.apply_filters()

    # ---------- Table rendering ----------
    def refresh_table(self, rows: list[dict]):
        self.tree.delete(*self.tree.get_children())
        for r in rows:
            values = [r.get(c, "") for c in COLUMNS]
            self.tree.insert("", "end", values=values)

    def apply_filters(self):
        q = self.search_var.get().strip().lower()

        min_points = to_int(self.min_points_var.get())
        min_play = to_int(self.min_playtime_var.get())
        min_kd = to_float(self.min_kd_var.get())
        min_hs = to_float(self.min_hs_var.get())

        def ok(r: dict) -> bool:
            if q and q not in (r.get("Player", "").lower()):
                return False

            if min_points is not None:
                pts = to_int(r.get("Points", ""))
                if pts is None or pts < min_points:
                    return False

            if min_play is not None:
                pl = to_int(r.get("Playtime", ""))
                if pl is None or pl < min_play:
                    return False

            if min_kd is not None:
                kd = to_float(r.get("K/D", ""))
                if kd is None or kd < min_kd:
                    return False

            if min_hs is not None:
                hs = to_float(r.get("HS%", ""))
                if hs is None or hs < min_hs:
                    return False

            return True

        filtered = [r for r in self.all_rows if ok(r)]
        self.refresh_table(filtered)

    # ---------- Sorting (toggle ASC/DESC) ----------
    def sort_by(self, col: str):
        # Toggle state
        asc = self.sort_state.get(col, True)
        self.sort_state[col] = not asc  # flip for next time

        # Get rows currently displayed
        children = self.tree.get_children("")
        if not children:
            return

        def key_of(item_id: str):
            v = self.tree.set(item_id, col)
            if col in NUMERIC_COLS_INT:
                n = to_int(v)
                return n if n is not None else -1
            if col in NUMERIC_COLS_FLOAT:
                n = to_float(v)
                return n if n is not None else -1.0
            # ScrapedAt sort as text works fine (ISO)
            return (v or "").lower()

        sorted_items = sorted(children, key=key_of, reverse=not asc)
        for idx, item_id in enumerate(sorted_items):
            self.tree.move(item_id, "", idx)


if __name__ == "__main__":
    App().mainloop()
