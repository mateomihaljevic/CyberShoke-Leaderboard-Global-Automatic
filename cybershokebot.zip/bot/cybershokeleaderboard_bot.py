import csv
import re
from datetime import datetime
from pathlib import Path
from playwright.sync_api import sync_playwright, TimeoutError as PWTimeoutError
import json

URL = "https://cybershoke.net/cs2/leaderboard/5x5"
DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)
MODE = "5x5"
STAMP = datetime.now().strftime("%Y-%m-%d_%H-%M")
OUT_CSV = DATA_DIR / f"cybershoke_5x5_{datetime.now().strftime('%Y-%m-%d_%H-%M')}.csv"
OUT_JSON = DATA_DIR / f"cybershoke_{MODE}_{STAMP}.json"
LATEST_JSON = DATA_DIR / "latest.json"

# ---------- Helpers ----------

def clean_spaces(s: str) -> str:
    if s is None:
        return ""
    s = s.replace("\u00A0", " ")
    s = re.sub(r"\s+", " ", s).strip()
    return s

def to_int_str(num_with_spaces: str) -> str:
    return re.sub(r"\s+", "", num_with_spaces or "")

def save_csv(rows, path):
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["Player", "Kills", "HS%", "K/D", "Playtime", "Points"],
            delimiter=";",
            quoting=csv.QUOTE_MINIMAL
        )
        writer.writeheader()
        writer.writerows(rows)

def save_json(rows, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(rows, f, ensure_ascii=False, indent=2)
        
# ---------- Regex: nađe svaki "N/A <name> <kills> <hs%> <kd> <playtime> h. <points>" bilo gdje u tekstu ----------

ROW_RE = re.compile(
    r"""
    N\/A\s+
    (?P<player>.+?)\s+
    (?P<kills>\d[\d\s]*)\s+
    (?P<hs>\d{1,3}%)\s+
    (?P<kd>\d+(?:\.\d+)?)\s+
    (?P<playtime>\d[\d\s]*)\s*h\.\s+
    (?P<points>\d[\d\s]*)
    """,
    re.VERBOSE | re.UNICODE
)

def parse_top10_from_text(text: str):
    text = text.replace("\u00A0", " ")  # NBSP -> space (ne ruši razmake u brojevima)
    out = []

    for m in ROW_RE.finditer(text):
        player = clean_spaces(m.group("player"))
        kills = to_int_str(m.group("kills"))
        hs = clean_spaces(m.group("hs"))
        kd = clean_spaces(m.group("kd"))
        playtime = to_int_str(m.group("playtime"))
        points = to_int_str(m.group("points"))

        out.append({
            "Player": player,
            "Kills": kills,
            "HS%": hs,
            "K/D": kd,
            "Playtime": playtime,   # sati
            "Points": points
        })

        if len(out) == 10:
            break

    return out


def scrape_top10():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(
            locale="en-US",
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/120.0 Safari/537.36"
            ),
            viewport={"width": 1400, "height": 900},
        )
        page = context.new_page()
        page.goto(URL, wait_until="domcontentloaded")

        try:
            page.wait_for_selector("text=Position", timeout=30000)
        except PWTimeoutError:
            print("Timeout: nije se pojavio 'Position' (blok/login moguće).")
            print("TITLE:", page.title())
            print("BODY (prvih 700):", clean_spaces(page.locator("body").inner_text())[:700])
            browser.close()
            return []

        page.wait_for_timeout(1500)

        body_text = page.locator("body").inner_text()  # ostavi original (sa newline)
        rows = parse_top10_from_text(body_text)

        if not rows:
            print("Nisam parsirao nijedan red (regex nije našao match).")
            print("BODY (prvih 1200):", clean_spaces(body_text)[:1200])

        browser.close()
        return rows


def main():
    rows = scrape_top10()
    if not rows:
        print("Nisam izvukao podatke (0 redova).")
        return

    save_csv(rows, OUT_CSV)
    print(f"Spremljeno {len(rows)} igrača u {OUT_CSV}")
    print("TOP 1:", rows[0])
    save_json(rows, LATEST_JSON)
    print(f"Spremljeno {len(rows)} igrača u {OUT_JSON}")


if __name__ == "__main__":
    main()
