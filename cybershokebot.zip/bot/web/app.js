let data = [];
let filtered = [];
let sortCol = null;
let sortAsc = true;

fetch("../data/latest.json")
  .then((r) => r.json())
  .then((json) => {
    data = json;
    filtered = [...data];
    render();
  });

function render() {
  const tbody = document.querySelector("tbody");
  tbody.innerHTML = "";

  filtered.forEach((r) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${r.Player}</td>
      <td>${r.Kills}</td>
      <td>${r["HS%"]}</td>
      <td>${r["K/D"]}</td>
      <td>${r.Playtime}</td>
      <td>${r.Points}</td>
    `;
    tbody.appendChild(tr);
  });
}

function applyFilters() {
  const q = document.getElementById("search").value.toLowerCase();
  const minP = Number(document.getElementById("minPoints").value || 0);
  const minKD = Number(document.getElementById("minKD").value || 0);

  filtered = data.filter(
    (r) =>
      r.Player.toLowerCase().includes(q) &&
      Number(r.Points) >= minP &&
      Number(r["K/D"]) >= minKD
  );

  render();
}

function resetFilters() {
  filtered = [...data];
  render();
}

function sortBy(col) {
  sortAsc = sortCol === col ? !sortAsc : true;
  sortCol = col;

  filtered.sort((a, b) => {
    let x = a[col],
      y = b[col];
    x = isNaN(x) ? x : Number(x);
    y = isNaN(y) ? y : Number(y);
    return sortAsc ? (x > y ? 1 : -1) : x < y ? 1 : -1;
  });

  render();
}
